import {initializeApp, auth} from "firebase-admin";
import functions = require("firebase-functions");

initializeApp();

/**
 * On User account create, assign custom claims (roles).
 */
exports.processSignUp = functions.auth.user().onCreate(async (user) => {
    if (
        !user.customClaims?.roles
    ) {
        const customClaims = {
            roles: ["UNASSIGNED"],
        };

        try {
            // Set custom user claims on this newly created user.
            await auth().setCustomUserClaims(user.uid, customClaims);
        } catch (error) {
            console.log(error);
        }
    }
});


/**
 * On user role change, update custom claims (roles).
 */
exports.processRoleChanges = functions.firestore
    .document("users/{userId}")
    .onWrite(async (change, context) => {
        // IF the roles haven't changed, return;
        if (change.before.data() &&
            change.before.data()?.roles == change.after.data()?.roles) {
            return;
        }

        /**
         * Set the new custom claims (roles) to the roles data
         * or if unassigned, set as unassigned.
        */
        const customClaims = {
            roles: (change.after.data()?.roles as []).length > 0 ?
                change.after.data()?.roles : ["UNASSIGNED"],
        };

        /**
         * Update the user's claims (roles)
         */
        try {
            await auth().setCustomUserClaims(
                context.params.userId, customClaims
            );
        } catch (error) {
            console.log(error);
        }
    });


// Notes for automating role changes on client-side:

// Update real-time database to notify client to force refresh.
//   const metadataRef = firestore().ref("metadata/" + user.uid);

// Set the refresh time to the current UTC timestamp.
// This will be captured on the client to force a token refresh.
//   await metadataRef.set({refreshTime: new Date().getTime()});
