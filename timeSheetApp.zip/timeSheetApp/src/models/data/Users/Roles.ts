export enum Roles {
    "UNASSIGNED" = "UNASSIGNED",
    "ON_SITE" = "ON_SITE",
    "OFF_SITE" = "OFF_SITE",
    "MANAGER" = "MANAGER",
    "ADMINISTRATOR" = "ADMINISTRATOR",
}

