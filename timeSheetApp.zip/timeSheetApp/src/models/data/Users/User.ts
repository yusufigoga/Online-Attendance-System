import { Timestamp } from "@firebase/firestore";
import { TimingEvent } from "src/models/events/timing_events";
import { Roles } from "./Roles";

export class User {
    name : {first: string, last: string};
    email : string;
    employeeIdentifier : string;
    roles : Roles[];
    managers: string[];
    status: {lastSeen: Timestamp};
    metadata: {registrationTimestamp: Timestamp};
    detailsConsentGiven: boolean | null;
    photoURL: string | null;
    firebaseUID?: string;

    constructor(
        name: {first: string, last: string}, 
        email: string, 
        employeeIdentifier: string, 
        roles: Roles[], 
        managers: string[],
        status: { lastSeen: Timestamp },
        metadata: {registrationTimestamp: Timestamp},
        detailsConsentGiven: boolean,
        photoURL: string,
        firebaseUID?: string,
    ) {        
        this.name = name;
        this.email = email;
        this.employeeIdentifier = employeeIdentifier;
        this.roles = roles;
        this.managers = managers;
        this.status = status;
        this.metadata = metadata;
        this.detailsConsentGiven = detailsConsentGiven;
        this.photoURL = photoURL;
        this.firebaseUID = firebaseUID;
    }
}
