import { DocumentReference, FieldValue, GeoPoint, Timestamp } from "@firebase/firestore";
import { EventType, TimingEvent } from "src/models/events/timing_events";
import { FlagType } from "src/models/events/flags";

export class TimeEntry {

    location: GeoPoint | null;
    timestamp: Timestamp | FieldValue;
    type: EventType;
    user: { employeeIdentifier: string, managers: string[], name: { first: string, last: string }, ref: DocumentReference };
    flags?: FlagType[];

    constructor(
        location: GeoPoint | null,
        timestamp: Timestamp | FieldValue,
        type: EventType,
        user: { employeeIdentifier: string, managers: string[], name: { first: string, last: string }, ref: DocumentReference },
        flags?: FlagType[],
    ) {
        this.location = location;
        this.timestamp = timestamp;
        this.type = type;
        this.user = user;
        this.flags = flags;
    }
}
