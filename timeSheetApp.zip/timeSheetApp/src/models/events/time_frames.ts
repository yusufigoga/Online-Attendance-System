//Required to use object as psuedo-'enum'
export type TimeFrameType = keyof typeof TimeFrame;
const todayDate = new Date(new Date().setHours(0, 0, 0, 0));
export const TimeFrame = {
    TODAY: {
        text: "Today",
        dateFrom: todayDate,
        dateTo: null,
    },
    YESTERDAY: {
        text: "Yesterday",
        dateFrom: new Date(new Date(new Date().setDate(todayDate.getDate() - 1)).setHours(0, 0, 0, 0)),
        dateTo: new Date(new Date(new Date().setDate(todayDate.getDate() - 1)).setHours(23, 59, 59, 999)),
    },
    THIS_WEEK: {
        text: "This Week",
        dateFrom: new Date(new Date(new Date().setDate(todayDate.getDate() - todayDate.getDay())).setHours(0, 0, 0, 0)),
        dateTo: new Date(new Date(new Date().setDate(todayDate.getDate() - todayDate.getDay() + 6)).setHours(23, 59, 59, 999)),
    },
    LAST_WEEK: {
        text: "Last Week",
        dateFrom: new Date(new Date(new Date().setDate(todayDate.getDate() - todayDate.getDay() - 7)).setHours(0, 0, 0, 0)),
        dateTo: new Date(new Date(new Date().setDate(todayDate.getDate() - todayDate.getDay() - 1)).setHours(23, 59, 59, 999)),
    },
    THIS_MONTH: {
        text: "This Month",
        dateFrom: new Date(todayDate.getFullYear(), todayDate.getMonth(), 1),
        dateTo: new Date(new Date(todayDate.getFullYear(), todayDate.getMonth() + 1, 0).setHours(23, 59, 59, 999)),
    },
    LAST_MONTH: {
        text: "Last Month",
        dateFrom: new Date(todayDate.getFullYear(), todayDate.getMonth() - 1, 1),
        dateTo: new Date(new Date(todayDate.getFullYear(), todayDate.getMonth(), 0).setHours(23, 59, 59, 999)),
    },
    CUSTOM: {
        text: "Custom",
        dateFrom: null,
        dateTo: null,
    },
} as const;