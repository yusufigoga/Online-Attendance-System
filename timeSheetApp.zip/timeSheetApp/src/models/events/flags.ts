//Required to use object as psuedo-'enum'
export type FlagType = keyof typeof Flag;
export const Flag = {
    MANUAL_ENTRY: {
        value: "MANUAL_ENTRY",
        icon: "mode",
        hint: "Manual Entry",
        color: "#393938" //Grey
    },
    HAS_NOTES: {
        value: "HAS_NOTES",
        icon: "notes",
        hint: "Has Notes",
        color: "#1866E1" //Blue
    },
    LATE: {
        value: "LATE",
        icon: "assignment_late",
        hint: "Late",
        color: "#FF7518" //ORANGE
    },
    AFTER_HOURS: {
        value: "AFTER_HOURS",
        icon: "alarm",
        hint: "After Hours",
        color: "#B53389" //Purple
    },
    OUT_OF_AREA: {
        value: "OUT_OF_AREA",
        icon: "wrong_location",
        hint: "Out of Area",
        color: "#00A86B" //Green
    },
} as const;