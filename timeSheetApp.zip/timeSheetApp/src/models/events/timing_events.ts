//Required to use object as psuedo-'enum'
export type EventType = keyof typeof TimingEvent;
export const TimingEvent = {
    CLOCK_IN: {
        value: "CLOCK_IN",
        icon: "schedule",
        hint: "Clock In",
        colorClass: "table-CLOCK_IN"
    },
    CLOCK_OUT: {
        value: "CLOCK_OUT",
        icon: "home",
        hint: "Clock Out",
        colorClass: "table-CLOCK_OUT"
    },
    // FORCED_CLOCK_IN: {
    //     value: "FORCED_CLOCK_IN",
    //     icon: "schedule",
    //     hint: "Force Clock In",
    //     colorClass: "table-FORCED_CLOCK_IN"
    // },
    // FORCED_CLOCK_OUT: {
    //     value: "FORCED_CLOCK_OUT",
    //     icon: "home",
    //     hint: "Force Clock Out",
    //     colorClass: "table-FORCED_CLOCK_OUT"
    // },
    AUTO_CLOCK_OUT: {
        value: "AUTO_CLOCK_OUT",
        icon: "home",
        hint: "Auto Clock Out",
        colorClass: "table-AUTO_CLOCK_OUT"
    },
} as const;