import { Component } from "@angular/core";
import { addDoc, collection, doc, Firestore, getDoc, getDocs, onSnapshot, query, QuerySnapshot } from "@angular/fire/firestore";
import { NgForm } from "@angular/forms";
import { DocumentData, QueryDocumentSnapshot } from "@firebase/firestore";
import { Observable } from "rxjs";
import { AuthService } from "./services/auth/auth.service";

@Component({
    selector: "app-root",
    templateUrl: "app.component.html",
    styleUrls: ["app.component.scss"]
})
export class AppComponent {
  title = "timeSheetApp";
  items: DocumentData[];
  submitted = false;
  //   itemsRef;
  constructor(
      // firestore: Firestore,
      // faAuth: AuthService
  ) {
      this.items = [];
      // faAuth.emailSignup("","");
      //   this.itemsRef = collection(firestore,"items");
      // getDocs(this.itemsRef).then((value: QuerySnapshot<DocumentData>)=>{
      //   this.items = value.docs.map(m => m.data());
      //   // console.log(this.items[0].data().test);
      // });

      //   const itemsQuery = query(collection(firestore, "items"));
    
      //   const unsubscribe = onSnapshot(itemsQuery, (querySnapshot) => {
      //       this.items = querySnapshot.docs.map(m => m.data());
      //   });
  }

  onCreateItem(PostForm: NgForm): void {
      this.submitted = true;
      if (PostForm.invalid) {
          console.log("INVALID");
          return;
      }
      const title= PostForm.value.title;
      const sub_title= PostForm.value.sub_title;
      const count= PostForm.value.number;
      const color= PostForm.value.color;

      //   addDoc(this.itemsRef,{title,sub_title,count,color});
  
      this.submitted = false;
      PostForm.reset();
  }
}
