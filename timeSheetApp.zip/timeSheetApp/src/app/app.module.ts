import { APP_INITIALIZER, NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { AppComponent } from "./app.component";
import { ServiceWorkerModule } from "@angular/service-worker";
import { environment } from "../environments/environment";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { InfiniteScrollModule } from "ngx-infinite-scroll";

import { initializeApp, provideFirebaseApp } from "@angular/fire/app";
import { provideFirestore, getFirestore, connectFirestoreEmulator } from "@angular/fire/firestore";
import { AppRoutingModule } from "./router/routing.module";
import { NavigationComponent } from "./components/navigation/navigation.component";
import { HomeComponent } from "./pages/home/home.component";
import { connectAuthEmulator, getAuth, provideAuth } from "@angular/fire/auth";
import { AuthenticationComponent } from "./pages/auth/authentication.component";
import { provideAnalytics, getAnalytics, ScreenTrackingService, UserTrackingService } from "@angular/fire/analytics";

import { ZXingScannerModule } from "@zxing/ngx-scanner";
import { TimeComponent } from "./pages/employee/time/time.component";
import { UserSettingsComponent } from "./pages/user/user-settings/user-settings.component";
import { ReportsComponent } from "./pages/administration/reports/reports.component";
import { UsersComponent } from "./pages/administration/users/users.component";
import { QrCodesComponent } from "./pages/administration/qr-codes/qr-codes.component";
import { ProfileComponent } from "./components/preferences/profile/profile.component";
import { PwaService } from "./services/pwa/pwa.service";


const initializer = (pwaService: PwaService) => () => pwaService.initPwaPrompt();
@NgModule({
    declarations: [
        AppComponent,
        NavigationComponent,
        HomeComponent,
        AuthenticationComponent,
        TimeComponent,
        ReportsComponent,
        UserSettingsComponent,
        UsersComponent,
        QrCodesComponent,
        ProfileComponent,
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        ReactiveFormsModule,
        InfiniteScrollModule,
        ServiceWorkerModule.register("ngsw-worker.js", {
            enabled: environment.production,
            // Register the ServiceWorker as soon as the app is stable
            // or after 30 seconds (whichever comes first).
            registrationStrategy: "registerWhenStable:30000"
        }),
        // AngularFireModule.initializeApp(environment.firebase),
        provideFirebaseApp(() => initializeApp(environment.firebase)),
        provideAuth(() => {
            const auth = getAuth();
            environment.useEmulators ? connectAuthEmulator(auth, "http://localhost:9099") : undefined;
            return auth;
        }),
        provideFirestore(() => {
            const firestore = getFirestore();
            environment.useEmulators ? connectFirestoreEmulator(firestore, "localhost", 8080) : undefined;
            // enableIndexedDbPersistence(firestore);
            return firestore;
        }),
        provideAnalytics(() => getAnalytics()),
        ZXingScannerModule,
    ],
    providers: [
        ScreenTrackingService, UserTrackingService,
        {provide: APP_INITIALIZER, useFactory: initializer, deps: [PwaService], multi: true},
    ],
    bootstrap: [AppComponent],
})
export class AppModule { }
