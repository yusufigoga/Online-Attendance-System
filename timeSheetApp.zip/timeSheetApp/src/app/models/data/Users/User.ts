// import { Timestamp } from "@firebase/firestore";

// export class User {
    
//     name : {first: string, last: string};
//     email : string;
//     employeeIdentifier : string;
//     roles : string[];
//     //Change to type of the enum
//     status: {latestEventTimestamp: Timestamp | null, latestEvent: string | null, lastSeen: Timestamp};
//     metadata: {registrationTimestamp: Timestamp};
//     detailsConsentGiven: boolean | null;

//     constructor(
//         name: {first: string, last: string}, 
//         email: string, 
//         employeeIdentifier: string, 
//         roles: string[], 
//         status: {latestEventTimestamp: Timestamp, latestEvent: string, lastSeen: Timestamp },
//         metadata: {registrationTimestamp: Timestamp},
//         detailsConsentGiven: boolean
//     ) {
//         this.name = name;
//         this.email = email;
//         this.employeeIdentifier = employeeIdentifier;
//         this.roles = roles;
//         this.status = status;
//         this.metadata = metadata;
//         this.detailsConsentGiven = detailsConsentGiven;
//     }
// }
