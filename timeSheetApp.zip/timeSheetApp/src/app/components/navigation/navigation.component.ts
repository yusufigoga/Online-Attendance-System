import { Component, OnInit } from "@angular/core";
import { Roles } from "src/models/data/Users/Roles";
import { AuthService } from "src/app/services/auth/auth.service";
import { PwaService } from "src/app/services/pwa/pwa.service";

@Component({
    selector: "app-navigation",
    templateUrl: "./navigation.component.html",
    styleUrls: ["./navigation.component.scss"]
})
export class NavigationComponent implements OnInit {

    // public empID: string | null = null; 
    public showManagementMenu: boolean | undefined;
    public employeeIdentifier: string | undefined;
    public userPhoto: string | undefined;


    // eslint-disable-next-line @typescript-eslint/no-empty-function
    constructor(public authService: AuthService, public pwaService: PwaService) {
        // if (authService) {
        //     this.empID = authService.getEmployeeIdentifier();
        // }
    }

    // eslint-disable-next-line @typescript-eslint/no-empty-function
    ngOnInit(): void {

        this.authService.user.subscribe(user => {
            //TODO: Fix weak workaround by implementing user data observable
            setTimeout(() => {
                this.showManagementMenu = this.shouldShowManagementMenu();
                // console.log(this.showManagementMenu);
            }, 1250);

            this.userPhoto = this.authService.getPhotoURL() ?? "../assets/img/no_profile_photo/no_profile_photo.png";
        });
    }

    shouldShowManagementMenu(): boolean {
        return this.authService.getUserRoles().some(role => [Roles.MANAGER, Roles.ADMINISTRATOR].includes(role));
    }

    logout(): void {
        this.authService.logout();
    }

    installPWA(): void{
        this.pwaService.promptEvent.prompt();
    }
}
