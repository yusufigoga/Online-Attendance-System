import { Component, OnInit } from "@angular/core";
import { updateProfile } from "@angular/fire/auth";
import { collection, doc, Firestore, setDoc } from "@angular/fire/firestore";
import { FormBuilder, FormControl } from "@angular/forms";
import { debounceTime } from "rxjs/operators";
import { AuthService } from "src/app/services/auth/auth.service";

@Component({
    selector: "app-profile",
    templateUrl: "./profile.component.html",
    styleUrls: ["./profile.component.scss"]
})
export class ProfileComponent implements OnInit {

    public employeeIdentifier: string | undefined;
    public userPhoto: string | undefined;

    public formDirtyOrLoading: boolean | undefined;

    private usersCollection = collection(this.afFirestore, "users");

    // User Profile Form
    userProfileForm = this.formBuilder.group({
        dataConsent: new FormControl(true),
        firstName: new FormControl(""),
        lastName: new FormControl(""),
    });
    // End User Profile Form

    constructor(public authService: AuthService, private formBuilder: FormBuilder, private afFirestore: Firestore,) {
        //
    }

    ngOnInit(): void {
        this.authService.user.subscribe(user => {
            this.userPhoto = this.authService.getPhotoURL() ?? "../assets/img/no_profile_photo/no_profile_photo.png";

            setTimeout(() => {
                (this.userProfileForm.get("dataConsent") as FormControl).setValue(this.authService.userData?.detailsConsentGiven, { emitEvent: false });
                (this.userProfileForm.get("firstName") as FormControl).setValue(this.authService.userData?.name.first, { emitEvent: false });
                (this.userProfileForm.get("lastName") as FormControl).setValue(this.authService.userData?.name.last, { emitEvent: false });
            }, 1525);
        });

        this.formValueChanges();
    }

    // Requires re-fetech events
    formValueChanges(): void {
        this.userProfileForm.valueChanges.pipe(
            debounceTime(100)
        ).subscribe((val: any) => {
            this.formDirtyOrLoading = this.userProfileForm.dirty || this.userProfileForm.invalid;
        });
    }

    saveProfileChanges(): void {
        if (this.userProfileForm.valid) {

            this.formDirtyOrLoading = true;

            const userDocRef = doc(this.usersCollection, this.authService.getUserFID());

            const updatedUserInfo = {
                detailsConsentGiven: (this.userProfileForm.get("dataConsent") as FormControl).value,
                name: {
                    first: (this.userProfileForm.get("firstName") as FormControl).value,
                    last: (this.userProfileForm.get("lastName") as FormControl).value,
                }
            };

            const newDisplayName = `${updatedUserInfo.name.first}${updatedUserInfo.name.last ? " " + updatedUserInfo.name.last : null}`;

            // Update profile
            setDoc(userDocRef, updatedUserInfo,
                { merge: true })
                .then(() => {
                    if (this.authService.fUser) {
                        updateProfile(this.authService.fUser, {
                            displayName: newDisplayName
                        }).then(() => {
                            // Profile updated!
                            // ...
                        }).catch((error) => {
                            // An error occurred
                            // ...
                        });
                    }
                }).finally(() => {
                    this.formDirtyOrLoading = false;
                    window.location.reload();
                });


        }
    }

}
