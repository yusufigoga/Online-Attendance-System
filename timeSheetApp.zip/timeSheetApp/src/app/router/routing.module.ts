import { NgModule } from "@angular/core";
// import { AngularFireAuth } from "@angular/fire/compat/auth";
import { AuthGuard, canActivate, customClaims, redirectLoggedInTo, redirectUnauthorizedTo } from "@angular/fire/auth-guard";
import { Routes, RouterModule } from "@angular/router";
import { pipe } from "rxjs";
import { map } from "rxjs/operators";
import { Roles } from "src/models/data/Users/Roles";
import { ProfileComponent } from "../components/preferences/profile/profile.component";
import { QrCodesComponent } from "../pages/administration/qr-codes/qr-codes.component";
import { ReportsComponent } from "../pages/administration/reports/reports.component";
import { UsersComponent } from "../pages/administration/users/users.component";
import { AuthenticationComponent } from "../pages/auth/authentication.component";
import { TimeComponent } from "../pages/employee/time/time.component";
import { UserSettingsComponent } from "../pages/user/user-settings/user-settings.component";

// const adminOnly = () => !hasCustomClaim("admin");
const redirectUnauthorizedToLogin = () => redirectUnauthorizedTo(["login"]);
// const redirectLoggedInToHome = () => redirectLoggedInTo(isManagerialStaff() ? "reports" : "");
const redirectLoggedInToHome = () => redirectLoggedInTo([""]);
const isManagerialStaff = () => {
    const pipeValue = pipe(customClaims, map(claims => {
        if (claims.roles?.includes(Roles.MANAGER) || claims.roles?.includes(Roles.ADMINISTRATOR)) {
            return true;
        }
        else {
            return false;
        }
    }));
    return pipeValue;
};

const routes: Routes = [
    { path: "", component: TimeComponent, canActivate: [AuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin } },
    { path: "reports", component: ReportsComponent, canActivate: [AuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin } },
    { path: "users", component: UsersComponent, canActivate: [AuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin } },
    { path: "qr-codes", component: QrCodesComponent, canActivate: [AuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin } },

    { path: "login", component: AuthenticationComponent, ...canActivate(redirectLoggedInToHome) },

    // Possibly movable to own 'app' module and router
    { path: "preferences", redirectTo: "preferences/profile", pathMatch: "full" },
    {
        path: "preferences", component: UserSettingsComponent, canActivate: [AuthGuard], data: { authGuardPipe: redirectUnauthorizedToLogin },
        children: [
            {
                path: "profile", // child route path
                component: ProfileComponent, // child route component that the router renders
            }]
    },

    // Catch All Path
    { path: "**", redirectTo: "", pathMatch: "full" }
];


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {
}