import { Platform } from "@angular/cdk/platform";
import { Injectable } from "@angular/core";
import { timer } from "rxjs";
import { take } from "rxjs/operators";

@Injectable({
    providedIn: "root"
})
export class PwaService {

    public promptEvent: any;
    public deviceType: "ios" | "not-ios" | undefined;

    constructor(
        // private bottomSheet: MatBottomSheet,
        private platform: Platform
    ) { }

    public initPwaPrompt(): void {
        console.log("INIT PWA?");
        if (!this.platform.IOS) {
            console.log("IS NOT IOS");
            window.addEventListener("beforeinstallprompt", (event: any) => {
                event.preventDefault();
                this.promptEvent = event;
                this.openPromptComponent("not-ios");
            });
        }
        if (this.platform.IOS) {
            console.log("IS IOS");
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const navigator: any = window.navigator;
            const isInStandaloneMode = ("standalone" in navigator) && (navigator["standalone"]);
            if (!isInStandaloneMode) {
                this.openPromptComponent("ios");
            }
        }
    }

    private openPromptComponent(deviceType: "ios" | "not-ios") {
        timer(3000)
            .pipe(take(1))
            .subscribe(() => {
                this.deviceType = deviceType;
                console.log(this.deviceType);
                console.log(this.promptEvent);
            }
                // this.bottomSheet.open(PromptComponent, { data: { mobileType, promptEvent: this.promptEvent } })
            );
    }
}