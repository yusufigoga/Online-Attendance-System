import { Injectable } from "@angular/core";
import { Auth, authState, getAdditionalUserInfo, getRedirectResult, GoogleAuthProvider, signInWithRedirect, User as fUser } from "@angular/fire/auth";
import { collection, doc, Firestore, runTransaction, setDoc, Timestamp } from "@angular/fire/firestore";
import { Router } from "@angular/router";
import { DocumentData, DocumentReference, getDoc } from "@firebase/firestore";
import { EMPTY, Observable, Subscription } from "rxjs";
import { Roles } from "src/models/data/Users/Roles";
import { User } from "src/models/data/Users/User";

@Injectable({ providedIn: "root" })
export class AuthService {
    public userData: User | null = null;
    public readonly user: Observable<fUser | null> = EMPTY;
    private readonly userDisposable: Subscription | undefined;
    public fUser: fUser | undefined;


    private usersCollection = collection(this.afFirestore, "users");
    private userStatsCollection = collection(this.afFirestore, "user_stats");

    constructor(
        private afAuth: Auth,
        private afFirestore: Firestore,
        private router: Router) {

        if (afAuth) {
            this.user = authState(this.afAuth);

            this.userDisposable = this.user.subscribe(user => {
                // console.log(user);
                if (user) {

                    this.fUser = user;

                    const userDocRef = doc(this.usersCollection, user.uid);

                    //Fetch User document data
                    getDoc(userDocRef).then((value) => {
                        this.userData = value.exists() ? value.data() as User : null;
                    });
                    // Update "lastSeen" timestamp on user document
                    setDoc(userDocRef,
                        {
                            status: {
                                lastSeen: Timestamp.now()
                            }
                        }, { merge: true });

                    //Process Auth Action
                    this.getAuthRedirect();
                } else {
                    user = null;
                    this.userData = null;
                }
            });
        }
    }

    async getAuthRedirect(): Promise<void> {
        const result = await getRedirectResult(this.afAuth);
        // As this API can be used for sign-in, linking and reauthentication,
        // check the operationType to determine what triggered this redirect
        // operation.
        const additionalUserInfo = result ? getAdditionalUserInfo(result) : null;
        const operationType = result?.operationType;

        if (operationType)
            console.log(operationType);
        if (additionalUserInfo)
            console.log(additionalUserInfo);

        //Registers the user in the Db if they are a new user
        if (result && additionalUserInfo?.isNewUser) {
            this.registerNewUser(result.user);
        }
    }

    /**
     * Registers user information in Firestore DB for newly registered users.
     * 
     * @param user The Firebase Auth User signing in
     */
    async registerNewUser(user: fUser): Promise<void> {
        const splitProvidedDisplayName = user.displayName?.split(" ") ?? [];
        const newUser: User = {
            name: { first: splitProvidedDisplayName[0] ?? "", last: splitProvidedDisplayName.length > 1 ? splitProvidedDisplayName.pop() ?? "" : "" },
            email: user.email ?? "",
            employeeIdentifier: "",
            roles: [Roles.UNASSIGNED],
            managers: [],
            status: { lastSeen: user.metadata.lastSignInTime ? Timestamp.fromMillis(Date.parse(user.metadata.lastSignInTime)) : Timestamp.now() },
            metadata: { registrationTimestamp: user.metadata.creationTime ? Timestamp.fromMillis(Date.parse(user.metadata.creationTime)) : Timestamp.now() },
            photoURL: user.photoURL,
            detailsConsentGiven: true,
        };

        const userDocRef = doc(this.usersCollection, user.uid);

        try {
            await runTransaction(this.afFirestore, async (transaction) => {
                const userStatsRef = doc(this.userStatsCollection, "stats");
                const userStatsDoc = await transaction.get(userStatsRef);
                if (!userStatsDoc.exists()) {
                    throw "[User Stats] document does not exist!";
                }

                const newNumUsers: number = userStatsDoc.data().numUsers + 1;

                const employeeIdPrefix = String.fromCharCode(this.getRandomIntInclusive(65, 90)) + String.fromCharCode(this.getRandomIntInclusive(65, 90));
                const employeeIdSuffix = `${newNumUsers}`.padStart(4, "0");
                newUser.employeeIdentifier = `${employeeIdPrefix}-${employeeIdSuffix}`;

                transaction.update(userStatsRef, { numUsers: newNumUsers });

                transaction.set(userDocRef, newUser, { merge: true });
            });
            console.log("Transaction successfully committed!");

        } catch (e) {
            console.log("Transaction failed: ", e);
        }

        this.userData = newUser;
    }

    getRandomIntInclusive(min: number, max: number): number {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1) + min); //The maximum is inclusive and the minimum is inclusive
    }

    async googleLogin(): Promise<void> {
        const provider = new GoogleAuthProvider();
        console.log(provider);
        await signInWithRedirect(this.afAuth, provider);
    }

    logout(): void {
        this.afAuth.signOut().then(() => {
            this.router.navigate(["/login"]);
        });
    }

    isLoggedIn(): boolean { return !!this.afAuth.currentUser; }

    getUserFID(): string {
        return this.fUser?.uid ?? "";
    }

    getUserName(): { first: string, last: string } { return { first: this.userData?.name?.first ?? "", last: this.userData?.name?.last ?? "" }; }

    getUserRoles(): Roles[] { return this.userData?.roles || [Roles.UNASSIGNED]; }

    getPhotoURL(): string | null {
        return this.fUser?.photoURL ?? null;
    }

    getManagers(): string[] { return this.userData?.managers || []; }

    async getUserRef(): Promise<DocumentReference<DocumentData>> {
        return doc(this.usersCollection, this.getUserFID());
    }
}



// login(email: string, password: string): void {
//     this.afAuth.signInWithEmailAndPassword(email, password)
//         .then(value => {
//             console.log("Nice, it worked!!");
//             this.router.navigateByUrl("/profile");
//         })
//         .catch(err => {
//             console.log("Something went wrong: ", err.message);
//         });
// }

// emailSignup(email: string, password: string): void {
//     this.afAuth.createUserWithEmailAndPassword("email", "password")
//         .then(value => {
//             console.log("Sucess", value);
//             this.router.navigateByUrl("/profile");
//         })
//         .catch(error => {
//             console.log("Something went wrong: ", error);
//         });
// }
