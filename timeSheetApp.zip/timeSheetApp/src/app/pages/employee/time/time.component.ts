import { Component, OnInit, ViewChild } from "@angular/core";
import { addDoc, collection, doc, Firestore, GeoPoint, getDoc, getDocs, limit, limitToLast, orderBy, query, serverTimestamp, Timestamp, where } from "@angular/fire/firestore";
import { ActivatedRoute, Router } from "@angular/router";
import { ZXingScannerComponent } from "@zxing/ngx-scanner";
import { AuthService } from "src/app/services/auth/auth.service";
import { TimeEntry } from "src/models/data/events/TimeEntry";
import { Roles } from "src/models/data/Users/Roles";
import { EventType, TimingEvent } from "src/models/events/timing_events";

@Component({
    selector: "app-time",
    templateUrl: "./time.component.html",
    styleUrls: ["./time.component.scss"]
})
export class TimeComponent implements OnInit {

    @ViewChild("scanner", { static: false })
    scanner!: ZXingScannerComponent;

    // Conditions for the different 'panels' to show
    public scannerHasError: boolean | undefined;
    public hasCameras: boolean | undefined;
    public hasCameraPermission: boolean | undefined;
    public scannerSuccess: boolean | undefined;
    public scannerInvalidCode: boolean | undefined;
    public isClockedIn: boolean | undefined;
    public scannerInitialized: boolean | undefined;

    public lastScanTimestampString: string | undefined;

    // QR Code ID
    code: string | null | undefined;
    // QR Code Hash Data
    hash: string | null | undefined;

    // Location
    public hasLocationAbility: boolean | undefined;
    public hasLocationPermission: boolean | undefined;
    public location: GeolocationPosition | undefined;

    public lastEvent: EventType | undefined;
    public lastEventTimestamp: Timestamp | undefined;

    private eventsCollection = collection(this.afFirestore, "events");
    private usersCollection = collection(this.afFirestore, "users");

    public scannerErrorText(): string {
        let errorText = "";
        if (this.scannerHasError) {

            errorText = this.hasCameraPermission ? "" : "Camera permission not granted";

            errorText = this.hasCameras ? errorText : "No Camera Found";
        }

        return errorText;
    }

    constructor(private router: Router, private route: ActivatedRoute, private afFirestore: Firestore, public authService: AuthService) {
    }

    async ngOnInit(): Promise<void> {

        this.code = this.route.snapshot.queryParamMap.get("code");
        this.hash = this.route.snapshot.queryParamMap.get("hash");
        if (this.code && this.hash) {
            this.scannerSuccess = true;
            this.lastScanTimestampString = new Date().toLocaleString();
            console.log(this.code);
            console.log(this.hash);
        }

        if (this.route.snapshot.queryParamMap.keys.length > 0) {
            this.router.navigateByUrl("/").then(() => {
                console.log(this.code);
                console.log(this.hash);
            });
        }

        this.authService.user.subscribe(async user => {

            if (user) {
                user.getIdTokenResult()
                    .then((idTokenResult) => {
                        if (window.history.state.navigationId == 1) {
                            const userRoles = idTokenResult.claims.roles as Roles[];
                            console.log("first load");
                            console.log(userRoles);
                            if (userRoles && (userRoles.includes(Roles.ADMINISTRATOR) || userRoles.includes(Roles.MANAGER))) {
                                this.router.navigate(["reports"]);
                            }
                        }
                    });
            }

            const userLatestEventQuery = query(this.eventsCollection, limitToLast(1), orderBy("timestamp"), where("user.ref", "==", await this.authService.getUserRef()));
            const querySnapshot = await getDocs(userLatestEventQuery);

            querySnapshot.forEach((doc) => {
                this.lastEvent = doc.data().type;
                this.lastEventTimestamp = doc.data().timestamp;
            });
            if (([/*TimingEvent.FORCED_CLOCK_IN.value, */TimingEvent.CLOCK_IN.value] as EventType[]).includes(this.lastEvent as EventType)) {
                this.isClockedIn = true;
            }

            this.scannerInitialized = true;
        });
    }

    //Clock In
    public async clockIn(): Promise<void> {
        if (this.clockInDisabled() || !this.authService.userData) {
            return;
        }

        this.location = await this.getLocation() || undefined;

        const timeEntry: TimeEntry = {
            location: this.location ? new GeoPoint(this.location.coords.latitude, this.location.coords.longitude) : null,
            timestamp: serverTimestamp(),
            type: TimingEvent.CLOCK_IN.value,
            user: {
                employeeIdentifier: this.authService.userData.employeeIdentifier,
                managers: this.authService.getManagers(),
                name: this.authService.getUserName(),
                ref: doc(this.usersCollection, await this.authService.getUserFID())
            },
            flags: [],
        };

        addDoc(this.eventsCollection, timeEntry).then(
            () => {
                this.lastEvent = TimingEvent.CLOCK_IN.value;
                this.lastEventTimestamp = Timestamp.now();
                this.isClockedIn = true;
            }, (error) => {
                //Handle invalid code, general errors, etc.
            }
        );
    }

    //Clock Out
    public async clockOut(): Promise<void> {
        if (this.clockOutDisabled() || !this.authService.userData) {
            return;
        }

        this.location = await this.getLocation() || undefined;

        const timeEntry: TimeEntry = {
            location: this.location ? new GeoPoint(this.location.coords.latitude, this.location.coords.longitude) : null,
            timestamp: serverTimestamp(),
            type: TimingEvent.CLOCK_OUT.value,
            user: {
                employeeIdentifier: this.authService.userData.employeeIdentifier,
                managers: this.authService.getManagers(),
                name: this.authService.getUserName(),
                ref: doc(this.usersCollection, this.authService.getUserFID())
            }
        };

        addDoc(this.eventsCollection, timeEntry).then(
            () => {
                this.lastEvent = TimingEvent.CLOCK_OUT.value;
                this.lastEventTimestamp = Timestamp.now();
                this.isClockedIn = false;
            }, (error) => {
                //Handle invalid code, general errors, etc.
            }
        );
    }

    private async getLocation(): Promise<GeolocationPosition | void> {
        if ("geolocation" in navigator) {
            this.hasLocationAbility = true;
            //Attempt location get
            const position = await this.getPosition({
                maximumAge: 30000,
                timeout: 2000
            });
            return position;
        } else {
            this.hasLocationAbility = false;
        }
    }

    private getPosition(options?: PositionOptions): Promise<GeolocationPosition | void> {
        return new Promise((resolve) =>
            navigator.geolocation.getCurrentPosition(resolve, (error) => {
                //See https://developer.mozilla.org/en-US/docs/Web/API/GeolocationPositionError
                switch (error.code) {
                    case 1:
                        {
                            //PERMISSION_DENIED
                            this.hasLocationPermission = false;
                            console.log("Location permission denied.");
                        }
                        break;
                    default:
                        break;
                }
                resolve();
            }, options)
        );
    }

    scanCompleteHandler(error: any): void {
        //POSSIBLY HAVE A COUNTER HERE (SEE SCAN POLLING RATE)
        //IF REACHES THRESHOLD, PERHAPS SHOW HELP MESSAGE/DETAILS
    }

    camerasFoundHandler(devices: MediaDeviceInfo[]): void {
        console.log(devices);
        this.hasCameras = true;
    }


    camerasNotFoundHandler(): void {
        // alert("NO CAMERAS FOUND");
        this.scannerHasError = true;
        this.hasCameras = false;
    }


    scanErrorHandler(error: any): void {
        console.log(error);
    }

    //Runs every cycle of scanner
    scanFailureHandler(error: any): void {
        console.log("FAILURE: " + error);
    }

    onTorchCompatible(isCompatible: boolean): void {
        console.log("TORCH COMPATIBLE: " + isCompatible);
    }

    onHasDeviceChange(hasDevice: boolean): void {
        console.log("HAS DEVICE: " + hasDevice);
        if (!hasDevice) {
            this.scannerHasError = true;
            this.hasCameras = false;
        } else {
            this.scannerHasError = false;
            this.hasCameras = true;
        }
    }

    onPermissionResponse(permissionResponse: boolean): void {
        console.log("PERMISSION: " + permissionResponse);
        if (!permissionResponse) {
            this.scannerHasError = true;
            this.hasCameraPermission = false;
        }
    }

    scanSuccessHandler(result: string): void {
        const resultRegEx = /\?code=(?!\.\.?$)(?!.*__.*__)(?<code>[^/]{1,1500})&hash=(?<hash>[A-z0-9]{1,32})&?$/;
        // const testString = "?code=hOleuktncSEaG7NbVTk4dd&hash=cOleuktncSEaG7NbVTk4hOleuktncSEd";
        if (resultRegEx.test(result)) {
            const codeResult: RegExpExecArray | null = resultRegEx.exec(result);
            const codeId = codeResult?.groups?.code;
            const codeHash = codeResult?.groups?.hash;
            if (codeId && codeHash) {
                this.code = codeId;
                this.hash = codeHash;
                this.scannerSuccess = true;
            }
            //TODO: REMOVE POST DEMO
            //FOR THE PRESENTATION/DEMONSTRATION ONLY
        } else if (result === "https://bit.ly/xbcad") {
            const codeId = "hOleuktncSEaG7NbVTk4dd";
            const codeHash = "cOleuktncSEaG7NbVTk4hOleuktncSEd";

            this.code = codeId;
            this.hash = codeHash;
            this.scannerSuccess = true;
        }
        else {
            this.code = undefined;
            this.hash = undefined;
            this.scannerInvalidCode = true;
            this.scannerSuccess = false;
        }
        this.lastScanTimestampString = new Date().toLocaleString();
    }

    //TODO: change these two to properties
    public clockInDisabled(): boolean {
        if (this.lastEvent && ([TimingEvent.CLOCK_IN.value/*, TimingEvent.FORCED_CLOCK_IN.value*/] as EventType[]).includes(this.lastEvent)) {
            return true;
        }
        return this.scannerHasError || this.scannerInvalidCode || !this.scannerSuccess;
    }

    public clockOutDisabled(): boolean {
        if (this.lastEvent && ([TimingEvent.CLOCK_OUT.value/*, TimingEvent.FORCED_CLOCK_OUT.value*/] as EventType[]).includes(this.lastEvent)) {
            return true;
        } else if (!this.lastEvent) {
            return true;
        }
        return false;
    }


}
