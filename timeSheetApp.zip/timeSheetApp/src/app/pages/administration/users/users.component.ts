import { Component, OnInit } from "@angular/core";
import { collection, DocumentSnapshot, FieldValue, Firestore, getDocs, limit, orderBy, query, QueryConstraint, Timestamp, where } from "@angular/fire/firestore";
import { FormBuilder, FormControl } from "@angular/forms";
import { debounceTime } from "rxjs/operators";
import { formatDate } from "@angular/common";
import { startAfter } from "@firebase/firestore";
import { ActivatedRoute, Router } from "@angular/router";
import { AuthService } from "src/app/services/auth/auth.service";
import { User } from "src/models/data/Users/User";
import { Roles } from "src/models/data/Users/Roles";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare let bootstrap: any;

@Component({
    selector: "app-users",
    templateUrl: "./users.component.html",
    styleUrls: ["./users.component.scss"]
})
export class UsersComponent implements OnInit {
    private usersCollection = collection(this.afFirestore, "users");
    private lastUserDocumentSnapshot: DocumentSnapshot | null = null;

    public users: User[] = [];
    public filteredUsers: User[] = [];

    public managedEmployees: User[] = [];

    // Search Params
    searchParamForm = this.formBuilder.group({
        //Managed Employee ID Filter
        managedEmployeeIdentifier: this.formBuilder.control(""),
        //Textual Filter
        textFilter: this.formBuilder.control("")
    });
    // End Search Params

    constructor(private afFirestore: Firestore, private formBuilder: FormBuilder, private router: Router, private activeRoute: ActivatedRoute, public authService: AuthService) {
    }

    ngOnInit(): void {
        this.managedEmployeeIDChanges();
        this.textFilterChanges();

        //TODO: Resolve this weak workaround by creating a user data observable
        this.authService.user.subscribe((user) => {
            setTimeout(() => {
                this.fetchManagedEmployees();
                this.getUsers();
            }, 1250);
        });
    }

    async fetchManagedEmployees(): Promise<void> {
        const managedEmployeesQuery = query(this.usersCollection, where("managers", "array-contains", this.authService.getUserFID()));
        const querySnapshot = await getDocs(managedEmployeesQuery);

        querySnapshot.forEach((doc) => {
            this.managedEmployees.push(new User(
                doc.data().name,
                doc.data().email,
                doc.data().employeeIdentifier,
                doc.data().roles,
                doc.data().managers,
                doc.data().status,
                doc.data().metadata,
                doc.data().detailsConsentGiven,
                doc.data().photoURL,
                doc.id));
        });
        console.log("managed employees:");
        console.log(this.managedEmployees);
    }

    getTimestamp(timestampObject: Timestamp | FieldValue): Date {
        if (timestampObject instanceof Timestamp) {
            return timestampObject.toDate();
        }
        return new Date();
    }

    // Requires re-fetech events
    managedEmployeeIDChanges(): void {
        this.searchParamForm.get("managedEmployeeIdentifier")?.valueChanges.pipe(
            debounceTime(450)
        ).subscribe(() => {
            this.getUsers();
        });
    }

    // Filter changes

    // Text Filter
    // Filter change
    textFilterChanges(): void {
        this.searchParamForm.get("textFilter")?.valueChanges.pipe(
            debounceTime(200)
        ).subscribe(() => {
            this.filterResults();
        });
    }
    // End Filter changes

    async getUsers(startAfterLastDoc?: boolean): Promise<void> {

        const managedEmployeeIdentifier = (this.searchParamForm.get("managedEmployeeIdentifier") as FormControl).value;

        const queryConstraints: QueryConstraint[] = [];

        console.log(managedEmployeeIdentifier);
        if (managedEmployeeIdentifier.trim().length > 0) {
            queryConstraints.push(
                where("employeeIdentifier", "==", managedEmployeeIdentifier));
        }

        const userRoles = this.authService.getUserRoles();
        console.log(userRoles);
        if (!userRoles.includes(Roles.ADMINISTRATOR)) {
            queryConstraints.push(
                where("managers", "array-contains", this.authService.getUserFID()));
        }

        queryConstraints.push(
            orderBy("status.lastSeen", "desc"),
            limit(20));

        if (!startAfterLastDoc) {
            this.users = [];
        } else
            queryConstraints.push(startAfter(this.lastUserDocumentSnapshot));

        const eventsQuery = query(this.usersCollection, ...queryConstraints);
        const querySnapshot = await getDocs(eventsQuery);

        querySnapshot.forEach((doc) => {
            this.users.push(new User(
                doc.data().name,
                doc.data().email,
                doc.data().employeeIdentifier,
                doc.data().roles,
                doc.data().managers,
                doc.data().status,
                doc.data().metadata,
                doc.data().detailsConsentGiven,
                doc.data().photoURL,
                doc.id));
        });
        this.lastUserDocumentSnapshot = querySnapshot.docs[querySnapshot.docs.length - 1];

        console.log(this.users);

        this.filterResults();
    }

    //Client-side filtering (due to Firestore query chaining limitations as 2021)
    filterResults(): void {
        this.filteredUsers = [];

        const textFilter: string = (this.searchParamForm.get("textFilter") as FormControl).value ?? "";


        // Populate Filtered Users Initially
        this.users.forEach(user => {
            this.filteredUsers.push(user);
        });
        console.log(this.filteredUsers);

        // Text Filter
        const trimmedFilterText = textFilter.trim().toLowerCase();
        if (trimmedFilterText.length > 0) {
            this.filteredUsers = this.filteredUsers.filter(user => {
                if (user.name.first.toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                if (user.name.last.toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                if (user.employeeIdentifier.toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                if (formatDate(new Date((user.status.lastSeen as Timestamp).seconds * 1000), "medium", "en").toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                return false;
            });
        }

        //  Tooltips
        setTimeout(() => {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll("[data-bs-toggle=\"tooltip\"]"));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }, 250);
    }

    onScroll(): void {
        if (this.lastUserDocumentSnapshot) {
            this.getUsers(true);
        }
    }

    onScrollUp(): void {
        // Possibly look at handling real-time/refresh on scroll up
    }

    // Exports formatted table data to comma-separated CSV format
    exportToCSV(): void {
        const data = [];
        const rows = document.querySelectorAll(".table-users tr:not(.collapsed-tr,.no-hover)");
        for (let i = 0; i < rows.length; i++) {
            const row = [], cols: NodeListOf<HTMLTableCellElement> = rows[i].querySelectorAll("td, th");

            for (let j = 0; j < cols.length; j++) {
                const columnText = cols[j].innerText;
                row.push(`"${columnText}"`);
            }
            data.push(row.join(","));
        }

        //Download
        const csv_file = new Blob([data.join("\n")], { type: "text/csv" });

        const download_link = document.createElement("a");

        download_link.download = "Users_List_" + formatDate(new Date(), "yyyy_MM_dd__HH_MM_SS", "en");

        download_link.href = window.URL.createObjectURL(csv_file);

        download_link.style.display = "none";

        document.body.appendChild(download_link);

        download_link.click();
    }

}

