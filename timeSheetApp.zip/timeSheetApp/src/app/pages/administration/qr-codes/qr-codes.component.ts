import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-qr-codes",
    templateUrl: "./qr-codes.component.html",
    styleUrls: ["./qr-codes.component.scss"]
})
export class QrCodesComponent implements OnInit {

    constructor() {
        //
    }

    ngOnInit() {
        //
    }

}
