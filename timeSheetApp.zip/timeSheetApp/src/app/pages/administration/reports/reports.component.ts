import { Component, OnInit } from "@angular/core";
import { collection, doc, DocumentSnapshot, FieldValue, Firestore, getDocs, limit, orderBy, query, QueryConstraint, runTransaction, Timestamp, where, writeBatch } from "@angular/fire/firestore";
import { TimeEntry } from "src/models/data/events/TimeEntry";
import { Flag } from "src/models/events/flags";
import { EventType, TimingEvent } from "src/models/events/timing_events";
import { FlagType } from "src/models/events/flags";
import { FormArray, FormBuilder, FormControl } from "@angular/forms";
import { TimeFrame, TimeFrameType } from "src/models/events/time_frames";
import { debounceTime } from "rxjs/operators";
import { formatDate } from "@angular/common";
import { startAfter } from "@firebase/firestore";
import { ActivatedRoute, Router } from "@angular/router";
import { AuthService } from "src/app/services/auth/auth.service";
import { User } from "src/models/data/Users/User";
import { Roles } from "src/models/data/Users/Roles";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare let bootstrap: any;

@Component({
    selector: "app-reports",
    templateUrl: "./reports.component.html",
    styleUrls: ["./reports.component.scss"]
})
export class ReportsComponent implements OnInit {
    readonly TimingEvent = TimingEvent;
    readonly Flag = Flag;
    readonly TimeFrame = TimeFrame;
    readonly FlagItems = Object.keys(Flag) as FlagType[];
    readonly EventTypes = Object.keys(TimingEvent) as EventType[];
    readonly TimeFrames = Object.keys(TimeFrame) as TimeFrameType[];

    private eventsCollection = collection(this.afFirestore, "events");
    private usersCollection = collection(this.afFirestore, "users");

    private lastEventDocumentSnapshot: DocumentSnapshot | null = null;

    public events: TimeEntry[] = [];
    public filteredEvents: TimeEntry[] = [];

    public managedEmployees: User[] = [];

    // Search Params
    searchParamForm = this.formBuilder.group({
        // time frame
        timeFrame: this.formBuilder.group({
            datePeriod: new FormControl(this.TimeFrames[0]),
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            dateFrom: new FormControl(formatDate(TimeFrame[this.TimeFrames[0]].dateFrom!, "yyyy-MM-dd", "en")),
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            dateTo: new FormControl(TimeFrame[this.TimeFrames[0]].dateTo ? formatDate(TimeFrame[this.TimeFrames[0]].dateTo!, "yyyy-MM-dd", "en") : null),
        }),
        //Managed Employee ID Filter
        managedEmployeeIdentifier: this.formBuilder.control(""),
        // event types
        eventParams: this.formBuilder.array([]),
        // flags
        flagParams: this.formBuilder.array([]),
        //Textual Filter
        textFilter: this.formBuilder.control("")
    });
    // End Search Params

    constructor(private afFirestore: Firestore, private formBuilder: FormBuilder, private router: Router, private activeRoute: ActivatedRoute, public authService: AuthService) {
        const todayMidnight = new Date();
        todayMidnight.setHours(0, 0, 0, 0);

        this.EventTypes.forEach(() => {
            (this.searchParamForm.get("eventParams") as FormArray).push(this.formBuilder.control(false));
        });

        this.FlagItems.forEach(() => {
            (this.searchParamForm.get("flagParams") as FormArray).push(this.formBuilder.control(false));
        });
    }

    ngOnInit(): void {

        this.fetchManagedEmployees();

        this.queryParameterInit();

        this.timeFrameChanges();
        this.eventTypesChanges();
        this.managedEmployeeIDChanges();

        this.flagTypesChanges();
        this.textFilterChanges();

        this.getEvents();
    }

    async fetchManagedEmployees(): Promise<void> {
        // console.log(this.authService.getUserFID());
        const managedEmployeesQuery = query(this.usersCollection, where("managers", "array-contains", this.authService.getUserFID()));
        const querySnapshot = await getDocs(managedEmployeesQuery);

        querySnapshot.forEach((doc) => {
            this.managedEmployees.push(new User(
                doc.data().name,
                doc.data().email,
                doc.data().employeeIdentifier,
                doc.data().roles,
                doc.data().managers,
                doc.data().status,
                doc.data().metadata,
                doc.data().detailsConsentGiven,
                doc.data().photoURL,
                doc.id));
        });

        // console.log(this.managedEmployees);
    }

    queryParameterInit(): void {
        const params = this.activeRoute.snapshot.queryParams;
        const datePeriod = (params["p"] && params["p"] as TimeFrameType) ?? null;
        const dateFrom = (params["p"] && params["p"] == this.TimeFrames[this.TimeFrames.length - 1]) ? params["fr"] : null;
        const dateTo = (params["p"] && params["p"] == this.TimeFrames[this.TimeFrames.length - 1]) ? params["t"] : null;
        const eventTypes: EventType[] = params["e"] && params["e"].length > 0 ? params["e"] : null;
        const flagTypes: FlagType[] = params["f"] && params["f"].length > 0 ? params["f"] : null;
        const managerID = null;
        const textFilter = params["fl"] && params["fl"].length > 0 ? params["fl"] : "";

        const flagParamsValues: boolean[] = this.FlagItems.reduce((arr: boolean[], val, index) => {
            if (flagTypes && flagTypes.includes(this.FlagItems[index])) {
                arr.push(true);
            } else arr.push(false);
            return arr;
        }, []);

        const eventParamValues: boolean[] = this.EventTypes.reduce((arr: boolean[], val, index) => {
            if (eventTypes && eventTypes.includes(this.EventTypes[index])) {
                arr.push(true);
            } else arr.push(false);
            return arr;
        }, []);

        let dateFromNewValue;
        let dateToNewValue;
        if (datePeriod) {
            if (datePeriod == this.TimeFrames[this.TimeFrames.length - 1]) {
                dateFromNewValue = dateFrom ? formatDate(dateFrom, "yyyy-MM-dd", "en") : null;
                dateToNewValue = dateTo ? formatDate(dateTo, "yyyy-MM-dd", "en") : null;
            } else {
                const timePeriodDateFrom = TimeFrame[datePeriod as TimeFrameType].dateFrom;
                const timePeriodDateTo = TimeFrame[datePeriod as TimeFrameType].dateTo;
                dateFromNewValue = timePeriodDateFrom ? formatDate(timePeriodDateFrom, "yyyy-MM-dd", "en") : null;
                dateToNewValue = timePeriodDateTo ? formatDate(timePeriodDateTo, "yyyy-MM-dd", "en") : null;
            }
        } else {
            const timePeriodDateFrom = this.TimeFrame[this.TimeFrames[0] as TimeFrameType].dateFrom;
            const timePeriodDateTo = TimeFrame[this.TimeFrames[0] as TimeFrameType].dateTo;
            dateFromNewValue = timePeriodDateFrom ? formatDate(timePeriodDateFrom, "yyyy-MM-dd", "en") : null;
            dateToNewValue = timePeriodDateTo ? formatDate(timePeriodDateTo, "yyyy-MM-dd", "en") : null;
        }

        datePeriod && (this.searchParamForm.get("timeFrame.datePeriod") as FormControl).setValue(datePeriod, { emitEvent: false });
        (this.searchParamForm.get("timeFrame.dateFrom") as FormControl).setValue(dateFromNewValue, { emitEvent: false });
        (this.searchParamForm.get("timeFrame.dateTo") as FormControl).setValue(dateToNewValue, { emitEvent: false });
        (this.searchParamForm.get("eventParams") as FormControl).setValue(eventParamValues, { emitEvent: false });
        (this.searchParamForm.get("flagParams") as FormControl).setValue(flagParamsValues, { emitEvent: false });
        (this.searchParamForm.get("textFilter") as FormControl).setValue(textFilter, { emitEvent: false });
    }

    getTimestamp(timestampObject: Timestamp | FieldValue): Date {
        if (timestampObject instanceof Timestamp) {
            return timestampObject.toDate();
        }
        return new Date();
    }

    // Requires re-fetech events
    timeFrameChanges(): void {
        this.searchParamForm.get("timeFrame.datePeriod")?.valueChanges.pipe(
            debounceTime(450)
        ).subscribe((val: any) => {
            const dateFrom = TimeFrame[val as TimeFrameType].dateFrom;
            const dateTo = TimeFrame[val as TimeFrameType].dateTo;

            (this.searchParamForm.get("timeFrame.dateFrom") as FormControl).setValue(dateFrom ? formatDate(dateFrom, "yyyy-MM-dd", "en") : null, { emitEvent: false });
            (this.searchParamForm.get("timeFrame.dateTo") as FormControl).setValue(dateTo ? formatDate(dateTo, "yyyy-MM-dd", "en") : null, { emitEvent: false });
        });

        this.searchParamForm.get("timeFrame")?.valueChanges.pipe(
            debounceTime(450)
        ).subscribe((val: any) => {
            this.getEvents();
        });
    }

    // Requires re-fetech events
    eventTypesChanges(): void {
        this.searchParamForm.get("eventParams")?.valueChanges.pipe(
            debounceTime(450)
        ).subscribe(() => {
            this.getEvents();
        });
    }

    // Requires re-fetech events
    managedEmployeeIDChanges(): void {
        this.searchParamForm.get("managedEmployeeIdentifier")?.valueChanges.pipe(
            debounceTime(450)
        ).subscribe(() => {
            this.getEvents();
        });
    }

    // Filter changes

    // Flags
    flagTypesChanges(): void {
        this.searchParamForm.get("flagParams")?.valueChanges.pipe(
            debounceTime(110)
        ).subscribe(() => {
            this.filterResults();
        });
    }

    // Text Filter

    // Filter change
    textFilterChanges(): void {
        this.searchParamForm.get("textFilter")?.valueChanges.pipe(
            debounceTime(200)
        ).subscribe(() => {
            this.filterResults();
        });
    }

    // Enf Filter changes

    async getEvents(startAfterLastDoc?: boolean): Promise<void> {

        const dateFromVal = (this.searchParamForm.get("timeFrame.dateFrom") as FormControl).value;
        const dateToVal = (this.searchParamForm.get("timeFrame.dateTo") as FormControl).value;
        const dateFrom = dateFromVal ? Timestamp.fromDate(new Date(new Date(dateFromVal).setHours(0, 0, 0, 0))) : null;
        const dateTo = dateToVal ? Timestamp.fromDate(new Date(new Date(dateToVal).setHours(23, 59, 59, 999))) : null;

        const managedEmployeeIdentifier = (this.searchParamForm.get("managedEmployeeIdentifier") as FormControl).value;

        const eventParams: boolean[] = (this.searchParamForm.get("eventParams") as FormControl).value;
        const eventParamValues: EventType[] = eventParams.reduce((arr: EventType[], val, index) => {
            if (val) {
                arr.push(this.EventTypes[index]);
            }
            return arr;
        }, []);

        const queryConstraints: QueryConstraint[] = [];

        //TODO: Look at this???
        if (managedEmployeeIdentifier.trim().length > 0) {
            queryConstraints.push(
                where("user.employeeIdentifier", "==", managedEmployeeIdentifier));
        }

        const userRoles = this.authService.getUserRoles();
        if (!userRoles.includes(Roles.ADMINISTRATOR)) {
            queryConstraints.push(
                where("user.managers", "array-contains", this.authService.getUserFID()));
        }

        queryConstraints.push(
            where("timestamp", ">=", dateFrom ?? Timestamp.now()),
            where("timestamp", "<=", dateTo ?? Timestamp.now()),
            orderBy("timestamp", "desc"),
            limit(20));

        if (eventParamValues.length > 0) {
            queryConstraints.push(where("type", "in", eventParamValues));
        }

        if (!startAfterLastDoc) {
            this.events = [];
        } else
            queryConstraints.push(startAfter(this.lastEventDocumentSnapshot));


        const eventsQuery = query(this.eventsCollection, ...queryConstraints);
        const querySnapshot = await getDocs(eventsQuery);

        querySnapshot.forEach((doc) => {
            this.events.push(new TimeEntry(doc.data().location, doc.data().timestamp, doc.data().type, doc.data().user, doc.data().flags));
        });
        this.lastEventDocumentSnapshot = querySnapshot.docs[querySnapshot.docs.length - 1];

        this.filterResults();
    }

    //Client-side filtering (due to Firestore query chaining limitations as 2021)
    filterResults(): void {
        this.filteredEvents = [];

        const textFilter: string = (this.searchParamForm.get("textFilter") as FormControl).value ?? "";
        const flagParams: boolean[] = (this.searchParamForm.get("flagParams") as FormControl).value;
        const flagParamsValues: FlagType[] = flagParams.reduce((arr: FlagType[], val, index) => {
            if (val) {
                arr.push(this.FlagItems[index]);
            }
            return arr;
        }, []);

        // Flags
        this.events.forEach(event => {
            if (flagParamsValues.length > 0) {
                if (event.flags && flagParamsValues.some(flagParams => (event.flags as FlagType[]).includes(flagParams))) {
                    this.filteredEvents.push(event);
                }
            } else
                this.filteredEvents.push(event);
        });

        // Text Filter
        const trimmedFilterText = textFilter.trim().toLowerCase();
        if (trimmedFilterText.length > 0) {
            this.filteredEvents = this.filteredEvents.filter(event => {
                if (event.user.name.first.toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                if (event.user.name.last.toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                if (event.user.employeeIdentifier.toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                if (formatDate(new Date((event.timestamp as Timestamp).seconds * 1000), "medium", "en").toLowerCase().indexOf(trimmedFilterText) > -1) {
                    return true;
                }
                return false;
            });
        }

        //Update query params
        this.updateQueryParams();

        //  Tooltips
        setTimeout(() => {
            const tooltipTriggerList = [].slice.call(document.querySelectorAll("[data-bs-toggle=\"tooltip\"]"));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        }, 250);
    }

    onScroll(): void {
        if (this.lastEventDocumentSnapshot) {
            this.getEvents(true);
        }
    }

    onScrollUp(): void {
        // Possibly look at handling real-time/refresh on scroll up
    }

    //Update query params based on filters and search params
    updateQueryParams(): void {

        const datePeriod = (this.searchParamForm.get("timeFrame.datePeriod") as FormControl).value ?? null;
        const dateFromVal = (this.searchParamForm.get("timeFrame.dateFrom") as FormControl).value ?? null;
        const dateToVal = (this.searchParamForm.get("timeFrame.dateTo") as FormControl).value ?? null;

        const dateFrom = dateFromVal ? new Date(new Date(dateFromVal).setHours(0, 0, 0, 0)).toISOString() : null;
        const dateTo = dateToVal ? new Date(new Date(dateToVal).setHours(23, 59, 59, 999)).toISOString() : null;
        const eventParams: boolean[] = (this.searchParamForm.get("eventParams") as FormControl).value;
        const flagParams: boolean[] = (this.searchParamForm.get("flagParams") as FormControl).value;
        const textFilter: string = (this.searchParamForm.get("textFilter") as FormControl).value.trim();

        const flagParamsValues: FlagType[] = flagParams.reduce((arr: FlagType[], val, index) => {
            if (val) {
                arr.push(this.FlagItems[index]);
            }
            return arr;
        }, []);


        const eventParamValues: EventType[] = eventParams.reduce((arr: EventType[], val, index) => {
            if (val) {
                arr.push(this.EventTypes[index]);
            }
            return arr;
        }, []);

        const queryParams = {
            /**Time Frame       |   period */
            p: datePeriod != this.TimeFrames[0] ? datePeriod : null,
            /**Time from        |   from */
            fr: datePeriod == this.TimeFrames[this.TimeFrames.length - 1] ? dateFrom : null,
            /**Time to          |   to */
            t: datePeriod == this.TimeFrames[this.TimeFrames.length - 1] ? dateTo : null,
            /**Event type(s)    |   events */
            e: eventParamValues.length > 0 ? eventParamValues : null,
            /**Flag type(s)     |   flags */
            f: flagParamsValues.length > 0 ? flagParamsValues : null,
            /**Manager ID(s)    |   managers */
            m: null,
            /**Text Filter      |   filter */
            fl: textFilter.length > 0 ? textFilter : null,
        };

        this.router.navigate(
            [],
            {
                relativeTo: this.activeRoute,
                queryParams: queryParams,
                queryParamsHandling: "merge"
            });
    }

    // Exports formatted table data to comma-separated CSV format
    exportToCSV(): void {
        const data = [];
        const rows = document.querySelectorAll(".table-reports tr:not(.collapsed-tr,.no-hover)");
        for (let i = 0; i < rows.length; i++) {
            const row = [], cols: NodeListOf<HTMLTableCellElement> = rows[i].querySelectorAll("td, th");

            for (let j = 0; j < cols.length; j++) {
                let columnText = cols[j].innerText;
                // Replace icon name with event type title
                if (j == 0 && i == 0) {
                    columnText = "Event Type";
                }

                // Replace icon name with event type
                if (i > 0 && j == 0) {
                    for (const eventType of this.EventTypes) {
                        if (TimingEvent[eventType as EventType].icon == columnText) {
                            columnText = eventType;
                            break;
                        }
                    }
                }

                // Replace icon name with flag type
                if (i > 0 && j == 4) {
                    let commaLengthCheck = 0;
                    let newColumnText = "";
                    for (const flagType of this.FlagItems) {
                        if (columnText.includes(Flag[flagType as FlagType].icon)) {
                            commaLengthCheck += Flag[flagType as FlagType].icon.length;

                            newColumnText += commaLengthCheck == columnText.length ? flagType : `${flagType},`;
                        }
                    }
                    columnText = newColumnText;
                }
                row.push(`"${columnText}"`);
            }
            data.push(row.join(","));
        }

        //Download
        const csv_file = new Blob([data.join("\n")], { type: "text/csv" });

        const download_link = document.createElement("a");

        download_link.download = "Attendance_Report_" + formatDate(new Date(), "yyyy_MM_dd__HH_MM_SS", "en");

        download_link.href = window.URL.createObjectURL(csv_file);

        download_link.style.display = "none";

        document.body.appendChild(download_link);

        download_link.click();
    }

}
