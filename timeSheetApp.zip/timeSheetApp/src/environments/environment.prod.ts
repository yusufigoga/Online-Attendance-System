export const environment = {
    production: true,
    firebase: {
        projectId: "xbcad-hospice",
        appId: "1:462175138826:web:76458eb62b69f8ba1f9bf3",
        storageBucket: "xbcad-hospice.appspot.com",
        locationId: "europe-west",
        apiKey: "AIzaSyBOZt1u7Rw9Xq4xMky3gEidOxI66Zl33bQ",
        authDomain: "xbcad-hospice.firebaseapp.com",
        messagingSenderId: "462175138826",
        measurementId: "G-GKG55KYQ7N",
    },
    // EMULATOR SUITE CONTROL
    useEmulators: false,
};
