// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    firebase: {
        projectId: "xbcad-hospice",
        appId: "1:462175138826:web:76458eb62b69f8ba1f9bf3",
        storageBucket: "xbcad-hospice.appspot.com",
        locationId: "europe-west",
        apiKey: "AIzaSyBOZt1u7Rw9Xq4xMky3gEidOxI66Zl33bQ",
        authDomain: "xbcad-hospice.firebaseapp.com",
        messagingSenderId: "462175138826",
        measurementId: "G-GKG55KYQ7N",
    },
    // EMULATOR SUITE CONTROL
    useEmulators: false,
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
